export const BaseColaboradores = [
    {
    id: "1",
    nombre: "Juan Soto",
    correo: "juans@colaborador.com",
    edad: "23",
    cargo: "Desarrollador FrontEnd",
    telefono: "99887766"
    },
    {
    id: "2",
    nombre: "Lucas Pailamilla",
    correo: "lucasp@colaborador.com",
    edad: "31",
    cargo: "Desarrollador Backend",
    telefono: "88779955"
    },
    {
    id: "3",
    nombre: "Diego Riquelme",
    correo: "diegor@colaborador.com",
    edad: "28",
    cargo: "Ingeniero DevOps",
    telefono: "99226644"
    },
]
    