# reactd3
React 1 - Desafio 3
G64- Desafio Latam
Trabajo realizado por Solange Benitez y Rodrigo Medina
